package com.nantian.enumeration;

/**
 * <p>ClassName: UserStatusEnum</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright©2014</p>
 * <p>Company: 广州南天电脑系统有限公司</p>
 * <p>Date: 2020-01-06</p>
 *
 * @author 刘晓辉
 * @version 1.0
 */
public enum UserStatusEnum {


}
