package com.nantian.exception;

public class SysInspectArchivesException extends Exception {

    public SysInspectArchivesException() {
    }

    public SysInspectArchivesException(String message) {
        super(message);
    }

}
