package com.nantian.exception;

public class DemocracyInsReException extends Exception{

    public DemocracyInsReException() {
    }

    public DemocracyInsReException(String message) {
        super(message);
    }
}
