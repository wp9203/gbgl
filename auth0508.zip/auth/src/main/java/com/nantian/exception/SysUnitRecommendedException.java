package com.nantian.exception;

public class SysUnitRecommendedException  extends Exception{

    public SysUnitRecommendedException() {
    }

    public SysUnitRecommendedException(String message) {
        super(message);
    }
}
