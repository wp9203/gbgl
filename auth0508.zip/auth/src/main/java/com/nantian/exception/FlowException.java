package com.nantian.exception;

public class FlowException extends Exception {
    public FlowException() {
    }

    public FlowException(String message) {
        super(message);
    }
}
