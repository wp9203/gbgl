package com.nantian.exception;

public class SysCandidateInfoException extends Exception {

    public SysCandidateInfoException() {
    }

    public SysCandidateInfoException(String message) {
        super(message);
    }
}

