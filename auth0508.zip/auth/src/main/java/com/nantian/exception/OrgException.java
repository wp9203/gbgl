package com.nantian.exception;

/**
 * @PackageName:com.nantian.exception
 * @ClassName: OrgException
 * @Description:
 * @author: YanCheng
 * @date 1/6/2020 10:41 AM
 */
public class OrgException extends Exception {
    public OrgException(String message) {
        super(message);
    }

    public OrgException() {
    }
}
