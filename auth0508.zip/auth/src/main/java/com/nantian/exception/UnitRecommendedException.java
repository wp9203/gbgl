package com.nantian.exception;

public class UnitRecommendedException extends Exception {
    public UnitRecommendedException() {
    }

    public UnitRecommendedException(String message) {
        super(message);
    }
}
