package com.nantian.exception;

public class FirstMotionException extends Exception {

    public FirstMotionException(String message) {
        super(message);
    }

    public FirstMotionException() {
    }
}
