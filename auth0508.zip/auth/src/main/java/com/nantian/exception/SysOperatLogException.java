package com.nantian.exception;

/**
 * @author Marry
 * @PackageName:com.nantian.exception
 * @ClassName: SysOperatLogException
 * @Description:
 * @date 1/16/2020 1:04 AM
 */
public class SysOperatLogException extends Exception {
    public SysOperatLogException() {
    }

    public SysOperatLogException(String msg) {
        super (msg);
    }
}
