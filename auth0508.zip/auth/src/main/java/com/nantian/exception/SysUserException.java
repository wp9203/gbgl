package com.nantian.exception;

/**
 * @PackageName:com.nantian.exception
 * @ClassName: SysUserException
 * @Description:
 * @author: YanCheng
 * @date 1/11/2020 1:04 AM
 */
public class SysUserException extends Exception {
    public SysUserException() {
    }

    public SysUserException(String message) {
        super(message);
    }
}
