package com.nantian.controller;

import com.github.pagehelper.Page;
import com.nantian.common.util.StringUtils;
import com.nantian.constant.Application;
import com.nantian.easytrade.annotation.ParameterObject;
import com.nantian.easytrade.annotation.Push;
import com.nantian.easytrade.annotation.Trade;
import com.nantian.easytrade.enumeration.ParamFormatEnum;
import com.nantian.easytrade.http.core.ApplicationContext;
import com.nantian.entity.sys.SysCandidateInfo;
import com.nantian.entity.sys.SysUnitRecommended;
import com.nantian.entity.sys.SysUser;
import com.nantian.enumeration.ErrorCodeEnum;
import com.nantian.exception.SysCandidateInfoException;
import com.nantian.exception.UnitRecommendedException;
import com.nantian.service.CandidateInfoService;
import com.nantian.service.FlowService;
import com.nantian.service.UnitRecommendedService;
import com.nantian.service.UserService;
import com.nantian.util.ResponeResult;
import com.nantian.vo.CandidateInfoVo;
import com.nantian.vo.ListCANVO;
import com.nantian.vo.ListUnitVO;
import com.nantian.vo.UnitRecommendedVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>ClassName: UserController</p>
 * <p>Description: 单位推荐管理控制器</p>
 * <p>Copyright: Copyright©2014</p>
 * <p>Company: 广州南天电脑系统有限公司</p>
 * <p>Date: 2020-04-16</p>
 *
 * @author wp
 * @version 1.0
 */

@Trade(channel = "api", transCode = "unitRecommended")
public class UnitRecommendedController {
    private static Logger log= LoggerFactory.getLogger(UnitRecommendedController.class);

    @Autowired
    UnitRecommendedService unitRecommendedService;
    @Autowired
    FlowService flowService;

    /**
     * 新增竞聘者
     * @param context 应用上下文
     * @param listUnitVO 新增的用户信息
     */
    @Push(requestFormat = ParamFormatEnum.JSON)
    public void add(ApplicationContext context, @ParameterObject ListUnitVO listUnitVO) throws UnitRecommendedException {
        try {
            System.out.println("listUnitVO"+listUnitVO);
            unitRecommendedService.addUnitRecommendedInfos(listUnitVO);
        } catch (UnitRecommendedException e) {
            context.setErrorMsg(ErrorCodeEnum.ERROR.getErrcode(), ErrorCodeEnum.ERROR.getErrmsg());
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 提交----先判断所有人员是否上传了材料，上传了则将sys_flow表中单位推荐的字段更新，否则所有人员都不提交，
     * @param context
     * @param unitRecommendedVO
     * @throws UnitRecommendedException
     */
    @Push(requestFormat = ParamFormatEnum.JSON)
    public void submit(ApplicationContext context, @ParameterObject UnitRecommendedVO unitRecommendedVO)throws UnitRecommendedException{
        System.out.println("tijiao");
        List<Long> ids = unitRecommendedVO.getIds();
        List<SysUnitRecommended>  list = new ArrayList<>();
        //先判断所选人员是否都有上传单位推荐材料
        for(Long id:ids){
            SysUnitRecommended sysUnitRecommended =  unitRecommendedService.querySysUnitRecommended(id);
            if (StringUtils.isBlank(sysUnitRecommended.getUnitRecommendedMaterial())) {
                context.setErrorMsg(ErrorCodeEnum.ERROR.getErrcode(), sysUnitRecommended.getCandidateName()+"没有上传单位推荐材料");
                return;
            }
            list.add(sysUnitRecommended);
        }
        //根据ID 更新到流程表字段 unit_re_id,unit_re_result,
        unitRecommendedService.updateSysFlowByUserID(list);

    }


}
