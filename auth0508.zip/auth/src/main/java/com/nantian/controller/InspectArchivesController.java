package com.nantian.controller;

import com.nantian.common.util.StringUtils;
import com.nantian.easytrade.annotation.ParameterObject;
import com.nantian.easytrade.annotation.Push;
import com.nantian.easytrade.annotation.Trade;
import com.nantian.easytrade.enumeration.ParamFormatEnum;
import com.nantian.easytrade.http.core.ApplicationContext;
import com.nantian.enumeration.ErrorCodeEnum;
import com.nantian.exception.SysInspectArchivesException;
import com.nantian.service.InspectArchivesService;
import com.nantian.vo.InspectArchivesVO;
import com.nantian.vo.ListInspectArchivesVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

@Trade(channel = "api", transCode = "inspectarchives")
public class InspectArchivesController {

    private static Logger log= LoggerFactory.getLogger(InspectArchivesController.class);

    @Autowired
    InspectArchivesService inspectArchivesService;



    /**
     * 档案核查新增
     * @param context 应用上下文
     * @param listInspectArchivesVO 新增的档案核查信息
     */
    @Push(requestFormat = ParamFormatEnum.JSON)
    public void add(ApplicationContext context, @ParameterObject ListInspectArchivesVO listInspectArchivesVO) throws SysInspectArchivesException {

        System.out.println(listInspectArchivesVO+"**************");
        for(int i=0;i<listInspectArchivesVO.getInfos().size();i++){

//            if(StringUtils.isNotBlank(listInspectArchivesVO.getInfos().get(i).getReviewIdentified())){
//                context.setErrorMsg(ErrorCodeEnum.PARAMETER_ERROR.getErrcode(), "审核认定为空");
//                return;
//            }
//            if(StringUtils.isNotBlank(listInspectArchivesVO.getInfos().get(i).getInspectRecord())){
//                context.setErrorMsg(ErrorCodeEnum.PARAMETER_ERROR.getErrcode(), "上传记录为空");
//                return;
//            }
            System.out.println(listInspectArchivesVO.getInfos().get(i)+"7777");
            InspectArchivesVO inspectArchivesVO=new InspectArchivesVO();
            inspectArchivesVO.setId(listInspectArchivesVO.getInfos().get(i).getId());
            inspectArchivesVO.setCandidateName(listInspectArchivesVO.getInfos().get(i).getCandidateName());
            inspectArchivesVO.setUnit(listInspectArchivesVO.getInfos().get(i).getUnit());
            inspectArchivesVO.setPosition(listInspectArchivesVO.getInfos().get(i).getPosition());
            inspectArchivesVO.setInspectTime(listInspectArchivesVO.getInfos().get(i).getInspectTime());
            inspectArchivesVO.setInspectProblem(listInspectArchivesVO.getInfos().get(i).getInspectProblem());
            inspectArchivesVO.setInspectRecord(listInspectArchivesVO.getInfos().get(i).getInspectRecord());
            inspectArchivesVO.setReviewIdentified(listInspectArchivesVO.getInfos().get(i).getReviewIdentified());

//            try {
//               inspectArchivesService.addInspectArchives(inspectArchivesVO);
//            } catch (SysInspectArchivesException e) {
//                context.setErrorMsg(ErrorCodeEnum.ERROR.getErrcode(), ErrorCodeEnum.ERROR.getErrmsg());
//                log.error(e.getMessage(), e);
//            }
        }
    }

    @Push(requestFormat = ParamFormatEnum.JSON)
    public void submit(ApplicationContext context, @ParameterObject ListInspectArchivesVO listInspectArchivesVO) throws SysInspectArchivesException {

        System.out.println(listInspectArchivesVO+"&&&&&&&");
    }

    }
