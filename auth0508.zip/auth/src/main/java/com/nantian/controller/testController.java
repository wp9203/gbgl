package com.nantian.controller;


import com.nantian.easytrade.annotation.Download;
import com.nantian.easytrade.annotation.Push;
import com.nantian.easytrade.annotation.Trade;
import com.nantian.easytrade.annotation.Upload;
import com.nantian.easytrade.http.core.ApplicationContext;
import com.nantian.easytrade.http.domain.FileModel;
import com.nantian.easytrade.http.domain.MultipartFile;

@Trade(channel = "api", transCode = "test")
public class testController {

    @Upload
    @Push
    public void upload(ApplicationContext context, MultipartFile file, MultipartFile file2, String name, int age) {
        System.out.println(file.getDiskFilePath());
        System.out.println(file.getFileName());
        System.out.println(file2.getDiskFilePath());
        System.out.println(file2.getFileName());
        System.out.println(name);
        System.out.println(age);
        context.setRstObject("upload", "上传成功了");
    }

    @Push
    @Download
    public FileModel download(String name, int age) {
        System.out.println(name);
        System.out.println(age);
        FileModel fileModel = new FileModel();
        fileModel.setFileName("需求工作量评估V1.8.xls");
        fileModel.setFilePath("/Users/liuxiaohui/Desktop/一对多内部帐代发需求工作量评估V1.8.xls");
        return fileModel;
    }
}
