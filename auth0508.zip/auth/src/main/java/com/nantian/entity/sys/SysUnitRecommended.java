package com.nantian.entity.sys;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.serializer.ToStringSerializer;

import java.io.Serializable;
import java.util.Date;

public class SysUnitRecommended implements Serializable {
    /**
     * 竞聘者id
     */
    @JSONField(serializeUsing = ToStringSerializer.class)
    private Long id;

    /**
     * 竞聘者名字
     */
    private String candidateName;

    /**
     * 竞聘者单位
     */
    private String candidateUnit;

    /**
     * 竞聘者职务
     */
    private String candidatePosition;

    /**
     * 单位推荐材料
     */
    private String unitRecommendedMaterial;

    private Date creationTime;

    private Date updateTime;

    /**
     * 职等
     */
    private String candidatePositionLevel;

    /**
     * 序列化版本号
     */
    private static final long serialVersionUID = 1L;

    /**
     * 获取 竞聘者id
     * @return 竞聘者id
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 竞聘者id
     * @param id 竞聘者id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 竞聘者名字
     * @return 竞聘者名字
     */
    public String getCandidateName() {
        return candidateName;
    }

    /**
     * 设置 竞聘者名字
     * @param candidateName 竞聘者名字
     */
    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    /**
     * 获取 竞聘者单位
     * @return 竞聘者单位
     */
    public String getCandidateUnit() {
        return candidateUnit;
    }

    /**
     * 设置 竞聘者单位
     * @param candidateUnit 竞聘者单位
     */
    public void setCandidateUnit(String candidateUnit) {
        this.candidateUnit = candidateUnit;
    }

    /**
     * 获取 竞聘者职务
     * @return 竞聘者职务
     */
    public String getCandidatePosition() {
        return candidatePosition;
    }

    /**
     * 设置 竞聘者职务
     * @param candidatePosition 竞聘者职务
     */
    public void setCandidatePosition(String candidatePosition) {
        this.candidatePosition = candidatePosition;
    }

    /**
     * 获取 单位推荐材料
     * @return 单位推荐材料
     */
    public String getUnitRecommendedMaterial() {
        return unitRecommendedMaterial;
    }

    /**
     * 设置 单位推荐材料
     * @param unitRecommendedMaterial 单位推荐材料
     */
    public void setUnitRecommendedMaterial(String unitRecommendedMaterial) {
        this.unitRecommendedMaterial = unitRecommendedMaterial;
    }

    public Date getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(Date creationTime) {
        this.creationTime = creationTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * 获取 职等
     * @return 职等
     */
    public String getCandidatePositionLevel() {
        return candidatePositionLevel;
    }

    /**
     * 设置 职等
     * @param candidatePositionLevel 职等
     */
    public void setCandidatePositionLevel(String candidatePositionLevel) {
        this.candidatePositionLevel = candidatePositionLevel;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", candidateName=").append(candidateName);
        sb.append(", candidateUnit=").append(candidateUnit);
        sb.append(", candidatePosition=").append(candidatePosition);
        sb.append(", unitRecommendedMaterial=").append(unitRecommendedMaterial);
        sb.append(", creationTime=").append(creationTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", candidatePositionLevel=").append(candidatePositionLevel);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}