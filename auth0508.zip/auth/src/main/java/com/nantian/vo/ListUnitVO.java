package com.nantian.vo;

import java.util.List;

public class ListUnitVO {

    List<UserVO> infos;

    public List<UserVO> getInfos() {
        return infos;
    }

    public void setInfos(List<UserVO> infos) {
        this.infos = infos;
    }

    @Override
    public String toString() {
        return "ListUnitVO{" +
                "infos=" + infos +
                '}';
    }
}
