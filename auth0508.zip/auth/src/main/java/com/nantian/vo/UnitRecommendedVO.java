package com.nantian.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.serializer.ToStringSerializer;

import java.util.Date;
import java.util.List;

public class UnitRecommendedVO {

    /**
     * 竞聘者id
     */
    @JSONField(serializeUsing = ToStringSerializer.class)
    private Long id;

    /**
     * 竞聘者名字
     */
    private String candidateName;

    /**
     * 竞聘者单位
     */
    private String candidateUnit;

    /**
     * 竞聘者职务
     */
    private String candidatePosition;
    /**
     * 姓名
     */
    private  String username;

    /**
     * 单位推荐材料
     */
    private String unitRecommendedMaterial;
    /**
     * 单位
     */
    private  String company ;
    /**
     * 职位
     */
    private String position;
    /**
     * 职等
     */
    private String positionLevel;

    private Date creationTime;

    private Date updateTime;

    /**
     * 职等
     */
    private String candidatePositionLevel;

    private List<Long> ids;

    public List<Long> getIds() {
        return ids;
    }

    public void setIds(List<Long> ids) {
        this.ids = ids;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public String getCandidateUnit() {
        return candidateUnit;
    }

    public void setCandidateUnit(String candidateUnit) {
        this.candidateUnit = candidateUnit;
    }

    public String getCandidatePosition() {
        return candidatePosition;
    }

    public void setCandidatePosition(String candidatePosition) {
        this.candidatePosition = candidatePosition;
    }

    public String getUnitRecommendedMaterial() {
        return unitRecommendedMaterial;
    }

    public void setUnitRecommendedMaterial(String unitRecommendedMaterial) {
        this.unitRecommendedMaterial = unitRecommendedMaterial;
    }

    public Date getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(Date creationTime) {
        this.creationTime = creationTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getCandidatePositionLevel() {
        return candidatePositionLevel;
    }

    public void setCandidatePositionLevel(String candidatePositionLevel) {
        this.candidatePositionLevel = candidatePositionLevel;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getPositionLevel() {
        return positionLevel;
    }

    public void setPositionLevel(String positionLevel) {
        this.positionLevel = positionLevel;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "UnitRecommendedVO{" +
                "id=" + id +
                ", candidateName='" + candidateName + '\'' +
                ", candidateUnit='" + candidateUnit + '\'' +
                ", candidatePosition='" + candidatePosition + '\'' +
                ", username='" + username + '\'' +
                ", unitRecommendedMaterial='" + unitRecommendedMaterial + '\'' +
                ", company='" + company + '\'' +
                ", position='" + position + '\'' +
                ", positionLevel='" + positionLevel + '\'' +
                ", creationTime=" + creationTime +
                ", updateTime=" + updateTime +
                ", candidatePositionLevel='" + candidatePositionLevel + '\'' +
                ", ids=" + ids +
                '}';
    }
}
