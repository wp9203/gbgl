package com.nantian.vo;

import com.nantian.entity.sys.SysInspectArchives;

import java.util.List;

public class ListInspectArchivesVO {

    List<SysInspectArchives> infos;

    public List<SysInspectArchives> getInfos() {
        return infos;
    }

    public void setInfos(List<SysInspectArchives> infos) {
        this.infos = infos;
    }

    @Override
    public String toString() {
        return "ListInspectArchivesVO{" +
                "infos=" + infos +
                '}';
    }
}
