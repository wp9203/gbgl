package com.nantian.service.impl;

import com.nantian.entity.sys.SysInspectArchives;
import com.nantian.exception.SysInspectArchivesException;
import com.nantian.mapper.sys.SysInspectArchivesMapper;
import com.nantian.service.InspectArchivesService;
import com.nantian.vo.InspectArchivesVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
public class InspectArchivesServiceImpl implements InspectArchivesService {

    private static Logger log = LoggerFactory.getLogger(InspectArchivesServiceImpl.class);

    @Autowired
    SysInspectArchivesMapper sysInspectArchivesMapper;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void addInspectArchives(InspectArchivesVO inspectArchivesVO) throws SysInspectArchivesException {

        SysInspectArchives sysInspectArchives=new SysInspectArchives();

        sysInspectArchives.setId(inspectArchivesVO.getId());
        sysInspectArchives.setCandidateName(inspectArchivesVO.getCandidateName());
        sysInspectArchives.setUnit(inspectArchivesVO.getUnit());
        sysInspectArchives.setPosition(inspectArchivesVO.getPosition());
        sysInspectArchives.setInspectTime(inspectArchivesVO.getInspectTime());
        sysInspectArchives.setInspectProblem(inspectArchivesVO.getInspectProblem());
        sysInspectArchives.setInspectRecord(inspectArchivesVO.getInspectRecord());
        sysInspectArchives.setReviewIdentified(inspectArchivesVO.getReviewIdentified());

        sysInspectArchives.setCreationTime(new Date());

        sysInspectArchivesMapper.insertSelective(sysInspectArchives);

    }
}
