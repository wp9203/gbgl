package com.nantian.service;


import com.nantian.entity.sys.SysUnitRecommended;
import com.nantian.exception.SysCandidateInfoException;

import com.nantian.exception.UnitRecommendedException;
import com.nantian.vo.ListUnitVO;
import com.nantian.vo.UnitRecommendedVO;

import java.util.List;


public interface UnitRecommendedService {

    /**
     * 添加一个竞聘者
     * @param unitRecommendedVos 需要添加的用户信息
     */
    void addUnitRecommendedInfos(ListUnitVO unitRecommendedVos) throws UnitRecommendedException;

    /**
     * 根据id 查询
     */
    SysUnitRecommended querySysUnitRecommended(Long id) throws UnitRecommendedException;

    /**
     * 更新流程表 sys_flow
     * @param sysUnitRecommendedList
     * @throws UnitRecommendedException
     */
    void updateSysFlowByUserID(List<SysUnitRecommended> sysUnitRecommendedList)throws UnitRecommendedException;

//    /**
//     * 分页查询
//     * @param page 当前第几页
//     * @param limit 每页数量
//     * @return 带分页的数据
//     */
//
//    Page<SysCandidateInfo> query(int page, int limit);
//
//
//    void delete(Long id);
//
//    /**
//     * 更新竞聘者信息
//     * @param candidateInfoVo 需要更新的竞聘者信息
//     */
//    void update(CandidateInfoVo candidateInfoVo);
//
//    /**
//     * 分页查询（民主推荐）
//     * @param page 当前第几页
//     * @param limit 每页数量
//     * @return 带分页的数据
//     */
//
//    Page<SysCandidateInfo> queryRe(int page, int limit);
//
//    /**
//     * 分页查询（公开竞聘）
//     * @param page 当前第几页
//     * @param limit 每页数量
//     * @return 带分页的数据
//     */
//
//    Page<SysCandidateInfo> queryCom(int page, int limit);
//
//    void checks(SysUser user);
}
