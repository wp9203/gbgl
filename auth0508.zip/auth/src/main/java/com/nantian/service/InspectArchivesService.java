package com.nantian.service;

import com.nantian.exception.SysInspectArchivesException;
import com.nantian.vo.InspectArchivesVO;

public interface InspectArchivesService {

    /**
     * 档案核查新增
     * @param inspectArchivesVO 需要添加的档案核查信息
     */
    void addInspectArchives(InspectArchivesVO inspectArchivesVO) throws SysInspectArchivesException;
}
