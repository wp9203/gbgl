package com.nantian.service.impl;



import com.nantian.common.util.StringUtils;
import com.nantian.entity.sys.SysFlow;
import com.nantian.entity.sys.SysUnitRecommended;
import com.nantian.entity.sys.SysUnitRecommendedExample;
import com.nantian.exception.UnitRecommendedException;
import com.nantian.mapper.sys.SysFlowMapper;
import com.nantian.mapper.sys.SysUnitRecommendedMapper;
import com.nantian.service.UnitRecommendedService;
import com.nantian.vo.ListUnitVO;
import com.nantian.vo.UnitRecommendedVO;
import com.nantian.vo.UserVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


@Service
public class UnitRecommendedServiceImpl implements UnitRecommendedService {

    private static Logger log = LoggerFactory.getLogger(UnitRecommendedServiceImpl.class);
    @Autowired
    SysUnitRecommendedMapper sysUnitRecommendedMapper;
    @Autowired
    SysFlowMapper sysFlowMapper;
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void addUnitRecommendedInfos(ListUnitVO listUnitVO) throws UnitRecommendedException {
        List<UserVO> userVOS = listUnitVO.getInfos();
        System.out.println("ServiceImpl");
        for(int i = 0;i<userVOS.size();i++){
            SysUnitRecommended sysUnitRecommended = new SysUnitRecommended();
            UserVO UserVO = userVOS.get(i);
            sysUnitRecommended.setId(UserVO.getId());
            sysUnitRecommended.setCandidateName(UserVO.getUsername());
            sysUnitRecommended.setCandidateUnit(UserVO.getCompany());
            sysUnitRecommended.setCandidatePosition(UserVO.getPosition());
            sysUnitRecommended.setCandidatePositionLevel(UserVO.getPositionLevel());

            //判断是否在数据已经存在该数据记录的ID
            SysUnitRecommendedExample sysUnitRecommendedExample = new SysUnitRecommendedExample();
            sysUnitRecommendedExample.createCriteria().andIdEqualTo(UserVO.getId());
            Long count = sysUnitRecommendedMapper.countByExample(sysUnitRecommendedExample);

            if( count > 0){//存在 更新
                sysUnitRecommended.setUpdateTime(new Date());
                sysUnitRecommendedMapper.updateByPrimaryKeySelective(sysUnitRecommended);
            }else{ // 插入
                sysUnitRecommended.setCreationTime(new Date());
                sysUnitRecommendedMapper.insertSelective(sysUnitRecommended);
            }



        }
    }

    /**
     * 根据ID查询表中是否存在记录
     * @param id
     * @return
     * @throws UnitRecommendedException
     */
    @Override
    public SysUnitRecommended querySysUnitRecommended(Long id) throws UnitRecommendedException {
        return sysUnitRecommendedMapper.selectByPrimaryKey(id);
    }

    /**
     * 更新sys_flow 表中 单位推荐字段
     * @param sysUnitRecommendedList
     * @throws UnitRecommendedException
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateSysFlowByUserID(List<SysUnitRecommended> sysUnitRecommendedList) throws UnitRecommendedException {

        for(int i=0;i<sysUnitRecommendedList.size();i++){
            SysUnitRecommended sysUnitRecommended = sysUnitRecommendedList.get(i);
            SysFlow sysFlow = new SysFlow();
            sysFlow.setUserid(sysUnitRecommended.getId());
            sysFlow.setStep2("2");
            sysFlow.setUnitReId(sysUnitRecommended.getId());
            if(sysUnitRecommended.getUpdateTime()==null){
                sysFlow.setUnitReResult(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(sysUnitRecommended.getCreationTime()));
            }else{
                sysFlow.setUnitReResult(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(sysUnitRecommended.getUpdateTime()));
            }
            sysUnitRecommendedMapper.updateByUserId(sysFlow);


        }
    }
}

